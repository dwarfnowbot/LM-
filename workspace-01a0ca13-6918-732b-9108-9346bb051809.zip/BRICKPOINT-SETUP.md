# BrickPoint — Installation & Setup Guide

**Theme:** BrickPoint 1.0.4 · **Package:** `brickpoint.zip` (3,481,084 bytes · 128 files · SHA-256 `3024acdeb27777832fa95fc9f1538082c68cc85f712bea6002f0e7e154642d4f`) · **Type:** standard WordPress theme (PHP templates, no build step, no React/Vite)
**Requires:** WordPress 6.0+ (tested on WordPress 7.1) · PHP 7.4+ · no WooCommerce, no required plugins
The package is ~3.4 MB because it carries the demo photos and demo video clips. They are copied into your Media Library on activation, so the pages have pictures and videos from the first minute.

---

## 0. Shortcut — Roman Urdu (sirf 5 steps)

1. WordPress admin kholein → **Appearance → Themes → Add New → Upload Theme** → **`brickpoint.zip`** select karein → **Install Now** → **Activate**.
2. Theme activate hone ke baad site ka pehla page kholein (ya 20 second wait karein). Theme khud hi: saare pages, categories, 4 locations, menus aur **demo data** (products, videos, projects, blogs, photos) install kar deta hai. Koi coding nahi.
3. **Products / Videos / Projects / Locations / Blog** pages kholein — pictures, text aur videos pehle se mojood honge. Har page **Elementor** se khulta hai: Pages → us page ke aage **Edit with Elementor** → heading, text, image, button, colour — sab kuch click karke badal sakte hain.
4. Naya item add karne ke liye: **Products → Add New Product** (ya Videos / Projects / Locations → Add New). Edit = item ke neeche **Edit**, Remove = **Trash**. Price, unit, availability, specifications, features, gallery, video, WhatsApp message, related items — sab fields usi screen par hain.
5. Demo data hatana ho: **BrickPoint → Setup & Content → step 7 → Remove demo content**. Aap ka apna content aur pages safe rehte hain.

**v1.0.4 update karne ke baad khud-ba-khud kya hota hai (koi kaam nahi karna):** Products ya categories ki **purani duplicate cheezein** (jo demo se pehle wali thi) hat jati hain, **pictures/videos ki width-height** theek ho jati hai, aur **koi tasveer text ke upar nahi** aati. Aap ka likha hua content — jis item mein aap ne text likha ho ya photo lagayi ho — kabhi delete nahi hota. Agar aap ne kisi page ko Elementor mein khud design kiya hai, wo page bhi safe rehta hai.

Agar site pehle toot gayi thi (admin nahi khul raha, "not allowed to access this page", Elementor sirf LOADING) to **§9a aur §9b** padhein — hal 2 minute ka hai aur koi coding nahi chahiye.

---

## 1. Install

1. WordPress admin → **Appearance → Themes → Add New → Upload Theme**
2. Choose **`brickpoint.zip`** → **Install Now** → **Activate**
3. On activation the theme automatically (the first visit may take ~20 seconds):
   - creates the product / video / project categories,
   - creates the 16 pages (Home, About Us, Products, Product Categories, SS7 Bricks, Construction Materials, Projects, Videos, Locations, For Contractors, For Builders, For Construction Companies, Blog, Contact, Privacy Policy, Terms and Conditions),
   - creates the 4 BrickPoint locations with the real Google Maps links,
   - creates and assigns the 5 navigation menus (Primary, Top Bar, 3 footer columns),
   - **installs the demo content**: 9 products, 4 videos, 6 projects, 4 blog posts, 23 photos/clips (copied into your Media Library) and the Elementor design of **13 pages** — so Products, Videos, Projects, Locations, Blog and every other page is already full of pictures and text when you open it,
   - trashes the untouched WordPress starter post/page ("Hello world!", "Sample Page") so your site starts on BrickPoint content instead of WordPress defaults,
   - sets pretty permalinks, rebuilds the rewrite rules **and re-registers the content types before that rebuild**, so `/projects/`, `/videos/`, `/locations/` and `/products/` open the *designed pages* immediately — not the plain archive,
   - puts the untouched "Sample Page" and "Hello world!" in the trash (they are only removed while they still hold the exact WordPress default text).

Nothing is overwritten on re-activation: existing pages, terms, locations, menus and any page you have built yourself with Elementor are left exactly as they are.

## 2. Guided setup (optional re-run)

**WordPress admin → BrickPoint → Setup & Content** has one button per step:

| Button | What it does |
|---|---|
| 1. Create pages | Re-checks/creates the required pages (with useful starter text + shortcodes) |
| 2. Create categories | 15 product categories, 15 video categories, 7 project categories |
| 3. Create locations | Masha Allah Bricks – Ram Thaman · Fine Bricks – Raja Jang · Masha Allah Bricks – Sattoki · BrickPoint Office |
| 4. Create menus | Primary / Top Bar / 3 footer menus, only empty menu locations |
| 5. Starter drafts | Clearly-labelled **draft** products and videos you can edit and publish |
| 6. Flush permalinks | Fixes 404s on `/products/`, `/videos/`, `/projects/`, `/locations/` |
| 7. Demo content | Reports how many demo items are on the site; **Re-check / finish demo import** (safe to press any time — only missing items are created) and **Remove demo content** (deletes the demo products/videos/projects/posts/photos and the demo page designs; your own content, the pages themselves and the 4 locations stay) |

**BrickPoint → Help & Docs** in the admin has the same information offline.

## 2b. The demo content — what is on the site and how to change it

Everything below is **normal WordPress content**, marked with a small “Demo” badge in the admin lists. Edit or delete any item and the pages update instantly.

| What you see | Where it is edited | Count installed |
|---|---|---|
| **Products** (name, price, unit, availability, specs, features, photos, gallery, video, WhatsApp text, related products) | **Products → All Products** | 9 |
| **Videos** (title, description, category, thumbnail, MP4/YouTube/Vimeo, duration, featured) | **Videos → All Videos** | 4 |
| **Projects** (title, category, location, gallery, scope, “Illustrative construction reference” label) | **Projects → All Projects** | 6 |
| **Blog posts** (title, text, image, category) | **Posts → All Posts** | 4 |
| **Photos / clips** (used by the demo pages and items) | **Media** | 23 |
| **Locations** – Masha Allah Bricks Company – Ram Thaman · Fine Bricks Company – Raja Jang · Masha Allah Bricks Company – Sattoki · BrickPoint Office, each with its real Google Maps link | **Locations → All Locations** | 4 |

**Page designs** – these 13 pages are built with Elementor widgets, so you can open any of them with *Edit with Elementor* and change every heading, text, image, button and column:

Home · About Us · Products · Product Categories · SS7 Bricks · Construction Materials · Projects · Videos · Locations · For Contractors · For Builders · For Construction Companies · Contact

The Blog, Privacy Policy and Terms pages use the normal page/post templates — edit them in the WordPress editor.

**Delete / replace / remove**
- One item: open it → **Trash** (Products, Videos, Projects, Posts, Locations all behave like normal WordPress content: Add New, Edit, Quick Edit, Trash, Restore).
- Add your own: **Add New Product** / **Add New Video** / **Add New Project** / **Add New Location** — every field (price, unit, availability, specs, features, gallery, video, WhatsApp message, related items, text, description) is on that screen.
- Everything at once: **BrickPoint → Setup & Content → 7. Demo content → Remove demo content**. Your own items, the pages and the locations stay.
- Never again: add `define( 'BRICKPOINT_SKIP_DEMO_CONTENT', true );` to `wp-config.php` before activating if you do not want the demo content on a new site.

**Do not want the demo items at all?** Remove them from step 7, then build your own — the grids on every page read from your content, so the moment you add your first real product the page shows it.

## 3. Settings (Appearance → Customize → BrickPoint)

| Section | What you set |
|---|---|
| **Brand** | Logo, brand name, tagline, phone, email, address, opening hours |
| **Social** | Facebook, Instagram, X/Twitter, TikTok, YouTube (leave blank to hide) |
| **WhatsApp** | WhatsApp number (default `923152850818`), greeting, closing line, default message, floating button on/off, mobile action bar on/off |
| **Hero** | Eyebrow, 3 headline lines, paragraph, 2 CTA labels + links, hero image, hero video (MP4 upload **or** YouTube/Vimeo URL), poster image, overlay opacity, video radius |
| **Design** | Colours (ink, brick, accent, sand, text, muted), typography, container width, section spacing, animation speed, Google Fonts on/off, sticky header on/off |
| **Footer** | Footer CTA title/text/buttons, about text, legal line, footer note |

Every value is a setting — the phone number, WhatsApp number, addresses and social links are never hard-coded in templates.

## 4. Content

### Products — *Products → Add New*
Name · slug · category · featured image · gallery · short description (Excerpt) · full description (editor) · **price**, **price label** ("Starting from"), **unit** ("per 1,000 bricks"), **minimum order**, **availability** (In stock / Limited / Made to order / On request / Out of stock) · **badge** ("Best seller") · **specifications** (repeater: Size, Type, Strength, Usage…) · **features** (one bullet per line) · **SKU/reference** · **delivery area** · **featured** toggle · product **video** (file or URL) · **brochure PDF** · **custom WhatsApp message** · **related products**.

### Videos — *Videos → Add New*
Title · slug · description · category · thumbnail · source (**self-hosted MP4 / YouTube / Vimeo / external URL**) · duration · captions (VTT) · featured toggle · display order · related products / projects / locations · published date.
Videos never autoload: the card shows the poster and the player (privacy-friendly `youtube-nocookie` / Vimeo) is created only after a click.

### Projects — *Projects → Add New*
Category · location · status · scope · year · gallery · video · linked products · disclaimer · **"Illustrative construction reference"** label toggle.

### Locations — *Locations → Add New*
Company · address · phone · opening hours · **Google Maps link** · directions link · coordinates · photo · video · linked products.
The four shipped locations already carry the real Maps URLs you provided.

### Product / video categories — *Products → Categories*, *Videos → Categories*
Icon, short description, image, banner, category video, WhatsApp message, order, **"Show on homepage"** toggle.

## 5. Elementor

The theme works perfectly **without** Elementor. If Elementor (free) is installed you get:

**17 BrickPoint widgets** (category *BrickPoint* in the widget panel):

Product Grid · Product Categories · Product Price & Availability · Product Gallery · Product Specs & Features · WhatsApp Button · Video Grid · Video (single) · Projects Grid · Location Cards · Social Links · Stats / Trust Strip · Contact / Quotation Form · Hero (with video) · SS7 Bricks Showcase · Section Heading · Breadcrumbs

All of them have content + style + responsive controls (columns per device, gap, aspect ratio, typography, colours, radius, borders, shadows, hover effects, pagination / load-more).

**Theme Builder locations** (Elementor → Templates → Theme Builder): Header, Footer, Single Product, Product Archive, Single Video, Video Archive, Single Project, Project Archive.
The theme renders its own header/footer/templates when no Elementor template is assigned, and automatically uses your Elementor template when one is.

> **Elementor Pro is required only for the Theme Builder features** (designing the header/footer and the single/archive templates visually). Product data is still edited in the normal WordPress screens.

## 6. Shortcodes (any editor, including Gutenberg)

```
[bp_products category="ss7-bricks" featured="1" limit="6" columns="3" orderby="date"]
[bp_product_categories limit="12" columns="4" home_only="0" style="card"]
[bp_videos category="product-videos" limit="9" columns="3" featured="1"]
[bp_projects category="residential" limit="6" columns="3"]
[bp_locations show_video="1"]
[bp_contact_form heading="Request a Quote"]
[bp_whatsapp label="Order on WhatsApp" message="Assalam-o-Alaikum BrickPoint"]
[bp_video id="123"]            [bp_video url="https://youtu.be/…"]
[bp_stats items="Years of experience::15::factory|Production sites::3::brick"]
```

## 7. Ordering & inquiries (no WooCommerce)

- Every product has **Order on WhatsApp** (pre-filled: product, category, unit, link) + **Request Quotation** + **Call now** + brochure.
- Optional quantity field is appended to the WhatsApp message in real time.
- Category pages and the hero have their own WhatsApp buttons.
- Floating WhatsApp button, mobile action bar (Call / WhatsApp / Quote) and share buttons.
- The contact form stores inquiries as **private `bp_inquiry` entries** (BrickPoint → Inquiries) and can email you; it is protected by a nonce, honeypot and a light IP rate limit.

## 8. Menus

`Appearance → Menus` — the five locations are **Primary**, **Top Bar**, **Footer – Products**, **Footer – Company**, **Footer – Support**. They are created and assigned for you; edit the items freely. Before a menu is assigned, the theme shows a sensible fallback menu.

## 9. Performance, security, SEO

- Lazy video embeds, poster images, `preload="metadata"`, hero video paused when off-screen, `playsinline`; reduced-motion visitors get a static poster (no autoplay).
- Only the CSS/JS the page needs is enqueued (video/product scripts load conditionally); Google Fonts are optional.
- All output escaped, all input sanitised, nonces on every form/AJAX endpoint, capability checks in the admin.
- Semantic HTML5, single `h1` per page, breadcrumbs, Open Graph tags, Organization/Product/VideoObject schema only where the data is real (no fake ratings or reviews), full RTL stylesheet, `.pot` translation file.

## 9c. v1.0.4 — purani duplicate cheezein, pictures/videos ki size, tasveer text ke upar

This release answers: *"product aur categories mein double cheezein aa rahi hain — pehli wali bhi hai aur nayi demo wali bhi; purani ko remove karein; pics aur videos ki width, height har page/section mein theek karein; kuch pics text ke upar aa rahi hain"*.

**1. Purani (demo se pehle wali) cheezein khud hat jati hain.** Earlier releases created a few placeholder drafts ("SS7 Bricks", "Cement", "Steel (Rebar)", three video placeholders and two project placeholders) — they are the reason a product could appear **twice**. On 1.0.4 the theme removes them automatically (on the first visit to `wp-admin`, or on the next front-end page view while you are logged in as an administrator).

Safe by design — an item is removed only when **all** of these are true:

- it was not created by the demo importer,
- it is still a draft (or carries an old "(add your video)" / "(add your photos)" marker),
- it has **no featured image**,
- its text is still exactly the shipped placeholder text (nothing written by you),
- and it either duplicates a demo item by title or is one of the known old placeholders.

Anything you have written, given a photo, or published is **never** touched. "Steel (Rebar)" and the demo "Steel Rebar" are recognised as the same item (case, brackets and punctuation are ignored). Duplicate *categories* (same name or same slug) are **merged**, not deleted: products are moved to the older category, a chosen category image is carried over, and only the empty copy is removed.

**Kya karna hai:** kuch nahi. Update ke baad ek dafa `wp-admin` kholein (ya site ka page refresh karein) — Products aur categories list mein ab sirf naye demo items honge. Apna banaya hua maal safe rahega. Chahein to **BrickPoint → Setup & Content → step 7** se demo content dobara re-check kar sakte hain.

**2. Pictures aur videos ki size har jagah theek.** The hero video card was rendered at only ~199 px wide (the widget default was 38% of its column). It now fills its column with a 16:10 box and can still be resized from Elementor (**Video width** / **Video min height**). A global media rule guarantees the same everywhere: card images and videos fill their box with `object-fit` (never stretched or squashed), inline content images keep their own ratio, embeds and inline videos keep a 16:9 box, and no picture or clip can be wider than its container.

**3. Koi tasveer text ke upar nahi.** The hero brick (SS7) is no longer absolutely placed on top of the text: it is a real item of the hero grid, so it always has its own space — in the right column, under the video card. Checked with a browser that measures every image/video against every text block on **16 pages × 2 viewports (1440 px and 390 px): 0 overlaps**, and **0 horizontal overflow** on **16 pages × 13 widths (320 → 1920 px)**.

**4. Saath mein.** The desktop header menu no longer wraps onto a second line (single line from 1440 px up; the header bar uses the full viewport width and nothing is ever hidden). Category cards with no image of their own now use the photo of the newest item in that category (no grey empty tiles). A category name containing "&" is shown correctly ("Renovation & Extension" instead of "&amp;"). Demo page designs are re-applied only on pages **you have not edited**, and if Elementor is installed *after* the theme (plain WordPress first), the demo designs are added automatically the first time Elementor is active.

## 9a. v1.0.3 — the fix for "Elementor page sirf LOADING dikhata hai", Projects/Videos/Locations khaali, demo data

This release answers the report: *"elementor ka through koi page open nahi ho raha bas loading chal raha, videos/projects/locations aur baqi pages sahi show nahi ho rahe, na proper content, na pics, na videos, aur add/remove/edit ka option bhi nahi hai"*.

**What was wrong (plain words).** Three separate problems:

1. **Saving a page with a BrickPoint widget could stop the whole request.** Elementor (3.16+) refuses any control that is registered outside a "section", and it stops the request with an error screen. Two of the theme's style helpers added controls after the last section was closed, so saving — or even opening — a page that contains a BrickPoint widget could abort. Fixed: the widgets now open a "Style" section automatically before adding style controls. Verified on all **17 widgets** (every one registers its controls cleanly).
2. **A freshly created page was still answered by the old archive rule.** The theme's content types (Products, Videos, Projects, Locations) own the same web addresses as the pages of the same name. On a brand-new install the pages are created during the first request, and WordPress had already stored the archive rules in that same request — so `/projects/`, `/videos/`, `/locations/` (and `/products/`) kept loading the *plain archive* view of the category until something flushed the rules. Result: your designed page, with all its Elementor content, pictures and videos, was never shown. Fixed: the content types are re-registered and their old archive rule is removed **before** the rewrite rules are rebuilt, and the rebuild itself now happens on the very first front-end page view if it is still pending. No Settings → Permalinks visit needed.
3. **The demo content itself.** v1.0.3 adds a full demo set (see §2b) and installs it automatically, so no page is empty. It also adds a lock so two simultaneous requests can never import the demo twice, and cleans up any duplicates if an earlier attempt created them.

**Bonus fixes in the same release:** the theme no longer leaves "headers already sent" warnings in the admin (the Customizer's editor styles are printed through the WordPress style API), the reveal animation can never leave content invisible in previews/screenshots/print, the header can no longer widen the page on 1280–1439 px screens (0 overflow at 320 / 375 / 390 / 414 / 480 / 768 / 820 / 1024 / 1280 / 1366 / 1440 / 1600 / 1920), and the demo import is protected so a single failing page can never take `wp-admin` down.

## 9b. v1.0.2 — the fix for "not allowed to access this page" + Elementor stuck on loading

If your site showed **"Sorry, you are not allowed to access this page."**, an **empty admin menu**, **no Add/Edit/Delete buttons** and an Elementor editor that only ever said **LOADING**, then your site was hit by the 1.0.0/1.0.1 capability bug. It is fixed in 1.0.2. Nothing in your content or database was damaged — replacing the theme's files is enough.

**What was wrong (plain words):** the four content types (Products, Videos, Projects, Locations) handed WordPress a list of capability names that re-used WordPress's own words ("read", "edit_posts", "delete_posts"). WordPress then routed *every* `current_user_can('read')` check through a "read this one post" check that had no post — which answers *no*. One wrong answer switched off the whole admin menu, the Elementor editor (its REST requests were refused) and every Add/Edit/Delete link. Two smaller problems were fixed in the same release: opening Elementor on an empty page left the homepage blank (Elementor marks a page as "built with Elementor" the moment you open the editor, even with zero widgets), and `/products/` was being served by the product archive instead of your Products page — which also made "Edit with Elementor" fail on that page.

### Fix your site now (choose one)

**A. You can still reach `wp-admin`** — Appearance → Themes → Add New → Upload Theme → `brickpoint.zip` → **Replace current with uploaded** (or Activate). Done — the admin comes back the moment the new files are in place.

**B. `wp-admin` does not open** — upload the new files over FTP / cPanel File Manager:
1. cPanel → **File Manager** → `public_html/wp-content/themes/`.
2. Rename `brickpoint` → `brickpoint-old` (safety copy).
3. Upload `brickpoint.zip` to `wp-content/themes/` and use **Extract** (or upload the `brickpoint` folder itself). You must end up with `wp-content/themes/brickpoint/style.css`.
4. Open `https://your-site.com/wp-admin/` → log in → Appearance → Themes → Activate **BrickPoint**.
5. Check the site, then delete `brickpoint-old`.

**C. Nothing opens at all** — use the BrickPoint Doctor (see §10, Method B): press **Rename the theme folder** → WordPress falls back to a default theme → your admin works → then install `brickpoint.zip` again.

### How to check it worked
- `wp-admin` opens with the full left-hand menu (Products, Videos, Projects, Locations, BrickPoint).
- Products → **Add New Product** button, and every row has Edit / Quick Edit / Trash / View.
- Pages → right-click the Home page → Edit with Elementor → the panel loads in a few seconds (no endless spinner).

## 10. If the site is broken — recovery (read this first)

**The most common cause is an incomplete upload.** cPanel File Manager / FTP uploads sometimes stop halfway, which leaves one PHP file cut in half. A half file is a fatal PHP error, so *every* page stops loading — the site, `wp-admin`, everything. The theme itself is not the problem; the half-uploaded file is.

### Does this match what you see?
- "There has been a critical error on this website." on the front end, **and**
- "Sorry, you are not allowed to access this page." when you open `/wp-admin/`, **and**
- a "file is corrupt" / "cannot be decompressed" error while uploading

→ Yes: use **Method A** below. It takes about two minutes and needs no coding.

### Method A — switch back to a working theme from cPanel (works even when wp-admin is dead)

1. cPanel → **File Manager** → open `public_html/wp-content/themes/`.
2. Right-click the `brickpoint` folder → **Rename** → rename it to `brickpoint-broken`.
   (Don't delete it if you want to inspect it later; renaming is enough. FTP users: just rename the folder and reload the site.)
3. Open `https://your-site.com/wp-admin/themes.php` in your browser and log in.
   WordPress now sees that the active theme's folder is gone, so it switches your site to a default theme (Twenty Twenty-Five) on its own.
4. The site and the dashboard are open again. Now install BrickPoint cleanly: upload a **fresh** `brickpoint.zip` (see §1) and activate it.
5. When you are happy with it, delete the `brickpoint-broken` folder.

> If your host gives you WP-CLI (many do), the same fix is:
> `wp theme activate twentytwentyfive --path=/home/USER/public_html` (run it from the folder that contains `wp-config.php`).

### Method B — the BrickPoint Doctor script (reports exactly which file is damaged)

Built for this exact situation. Two files ship with the theme: `brickpoint-doctor.php` and `brickpoint-doctor.manifest.json` (they must sit side by side).

1. Open `brickpoint-doctor.php` in Notepad / VS Code and change the key line near the top:
   `$BP_KEY = 'change-this-key-123';` → `$BP_KEY = 'your-own-random-string';`
2. Upload **both** files into your WordPress folder — the one that contains `wp-config.php` (usually `public_html/`).
3. Visit `https://your-site.com/brickpoint-doctor.php?key=your-own-random-string`.
4. Read the report:
   - **Section 3** shows the installed theme version (1.0.3 expected), then lists missing, older/changed or truncated files by name — that tells you exactly what an interrupted upload destroyed or which release you are on.
   - **Section 4** has three buttons, in the order they should be used:
     1. **Rename the theme folder** — safest, always works, no database access needed. Do this first.
     2. **Switch to a default theme** — changes the active theme (`template` / `stylesheet` options).
     3. **Enable theme safe mode** — adds `define( 'BRICKPOINT_SAFE_MODE', true );` to `wp-config.php` (a backup `wp-config.php.brickpoint-backup` is saved first). The theme then stops loading on its own, so the site and dashboard come back even while the damaged files are still on the server.
5. After any repair: reinstall BrickPoint from a fresh, complete `brickpoint.zip`, then delete `brickpoint-doctor.php` and `brickpoint-doctor.manifest.json` from the server.

The doctor only reads until you press a button, and it never touches your content, posts or database rows other than the two theme options in step 2 of section 4.

### How to upload so this never happens again

- Upload `brickpoint.zip` through **Appearance → Themes → Add New → Upload Theme** (WordPress unzips it server-side). The zip is ~3.4 MB / 128 files; it contains the demo photos and clips, so the upload takes a little longer than a plain theme. If it stops or times out, retry (or use File Manager → Upload → Extract).
- If you must use File Manager/FTP, upload the **zip** and use **Extract** on the server — never drag the individual 128 files one by one over a slow connection.
- After extracting, check that `wp-content/themes/brickpoint/functions.php` is ~6.3 KB, that `inc/demo-content.php` is ~72 KB, and that the folders `demo/layouts/` (13 `.json` files) and `assets/demo/` (19 photos + 4 clips) exist in the theme folder. A file that is much smaller than expected is a half upload.
- Windows check of the zip before uploading: open PowerShell and run
  `Get-FileHash .\brickpoint.zip -Algorithm SHA256`
  The result must be `d29b952149e81107c49311ea9242463bf58dc64bc626998a91257a0eb79a5af5`
  (and the file must be 3,474,714 bytes). If it differs, download the zip again.

### Why BrickPoint 1.0.1 cannot take the site down

- `functions.php` now loads every module inside its own `try { … } catch (\Throwable)` block, so one damaged or fatal file no longer kills the whole theme or the admin.
- If a module does fail, the theme logs it (`[BrickPoint] inc/xyz.php - …`), shows a warning box in the dashboard, and serves a small self-contained fallback page instead of the Word-forbidden "critical error" screen.
- `BRICKPOINT_SAFE_MODE` (see Method B, button 3) skips all theme modules entirely — an instant rescue switch that works even when the theme folder is damaged.
- On activation, the content-seeding routine runs inside its own `try/catch`, so a hosting quirk during activation can no longer break a fresh install.
- The theme requires PHP 7.4+; on older PHP it steps aside quietly instead of throwing errors.

### Other symptoms

| Symptom | Fix |
|---|---|
| "Sorry, you are not allowed to access this page." alone (site still loads) | That is WordPress refusing `/wp-admin/` — usually a user-role/cookie problem, or a security plugin. Log out, clear cookies, log in again; if it persists, disable security plugins by renaming their folders. |
| "File is corrupt" / "not a valid plugin/theme" during upload | The upload was cut short. Re-download the zip, check the hash above, and upload again. |
| Dashboard works, front end is white | Reinstall the theme (fresh zip), or press **Rename the theme folder** in the Doctor to hand the site back to a default theme. |
| Everything broken right after a **plugin** update | Rename that plugin's folder in `wp-content/plugins/` — the same trick as Method A, for plugins. |

## 11. Troubleshooting

| Symptom | Fix |
|---|---|
| `/products/` shows 404 | BrickPoint → Setup & Content → **Flush permalinks**, or Settings → Permalinks → Save |
| Themes page says the zip is invalid | Make sure you upload `brickpoint.zip` itself (it contains a `brickpoint/` folder), not an extracted folder. See §10 for a full recovery walkthrough |
| Hero video not playing | Some browsers block autoplay until interaction — the poster stays visible and the play/pause button appears |
| Fonts look like Arial/Times | Customize → BrickPoint → Design → **Load Google Fonts** off, or a plugin/CSP is blocking `fonts.googleapis.com` |
| Elementor widgets missing | Elementor must be active; you will find the 17 widgets and the **BrickPoint** category in the Widgets panel. BrickPoint → Setup shows a health check for the widget files |
| "Sorry, you are not allowed to access this page." / empty admin menu | Update to **1.0.2** — see §9b. On 1.0.0/1.0.1 the content-type capabilities broke every admin capability check |
| Elementor editor stays on LOADING | Same cause — see §9b. If it still happens on 1.0.2, open Elementor → Tools → and clear the "Elementor cache", then reload the editor |
| Homepage looks empty | The homepage shows the designed sections until the page has real content. Empty pages are not blank because of a theme error — see §9b and §4 |
| `/projects/`, `/videos/`, `/locations/` or `/products/` show the plain archive (no page hero/cards, my own design missing) | BrickPoint → Setup & Content → **Flush permalinks**. Fixed automatically on 1.0.3 (the theme rebuilds the rules itself), so update if you still see it |
| A page is empty / has no pictures | On 1.0.3 every page is installed with demo content and photos. If a page is still empty: BrickPoint → Setup & Content → **7. Demo content → Re-check / finish demo import**, and make sure that page's design was not deleted by hand |
| Products/Videos/Projects/Locations cannot be added, edited or deleted | Update to **1.0.3** (or at least 1.0.2, see §9b) — the old capability bug switched those buttons off |

## 12. Notes about this build

- The theme follows the BrickPoint brief and its design tokens (ink `#0e0f11`, brick `#c1440e`, accent `#e2571e`, sand `#f5f1ea`; Barlow Condensed headings / Inter body). No earlier project files were present in the workspace to copy a design from, so the layout system was built from the written specification.
- Starter content is deliberately generic and clearly labelled; no customers, certifications, statistics, delivery promises or housing-society claims were invented. Project references that are not verified are shown with the **"Illustrative construction reference"** label — edit them to your real projects.
- Keep `brickpoint.zip` as your master copy (v1.0.4, 3,481,084 bytes, SHA-256 `3024acde…642d4f`). For code customisations use a child theme; theme updates will not touch it.
- Version history: **1.0.4** (this build) — the old pre-demo placeholders are removed automatically, so Products and categories no longer show anything twice (only untouched drafts are removed: an item with your own text, a photo, or a published status is always kept); duplicate categories are merged; the hero video card renders at full column width (it was 199 px); a global media rule keeps every image/video/embed inside its container with the right ratio; the SS7 hero brick is a grid item, so it can never cover the heading, the buttons or the video in any of the three hero video layouts; category cards fall back to the newest item photo (no grey tiles); "&" in category names is decoded for display; the desktop header menu stays on one line from 1440 px up; demo designs are re-applied only on pages you have not edited and are added automatically if Elementor is activated after the theme. Verified: 0 image-over-text overlaps (16 pages × 2 viewports), 0 horizontal overflow (16 pages × 13 widths 320–1920 px), a 1.0.3 → 1.0.4 upgrade removes all 11 legacy drafts and leaves 9 products / 4 videos / 6 projects / 4 locations, and both a plain-WordPress install and one with Elementor return 200 on all 16 pages with the Elementor editor opening on all 7 designed pages.
- **1.0.3** — demo content for every page (9 products, 4 videos, 6 projects, 4 blog posts, 4 locations, 23 photos/clips, 13 Elementor page designs) installed automatically, safe re-import and one-click removal; Elementor control-section guard so saving/opening a page with BrickPoint widgets can never fail; content types re-registered before the permalink rebuild plus a self-healing flush, so the designed Projects/Videos/Locations/Products pages always win over the archives; demo-import lock and de-duplication; Sample Page / Hello world moved to the trash; admin header warnings removed; responsive header fix (no horizontal scroll 320–1920 px); reveal animations can no longer hide content in previews.
- **1.0.2** — critical capability fix (admin menu / Elementor editor / add-edit-delete working again), Elementor-preview rendering for the front page, archive-vs-page slug collision guard, "page has real content" check so an empty Elementor page never blanks the homepage. See §9b.
- **1.0.1** — safety-hardened bootstrap, per-module error isolation, dashboard error notice, self-contained fallback page, `BRICKPOINT_SAFE_MODE` rescue switch, activation wrapped in `try/catch`; plus the standalone **BrickPoint Doctor** recovery script (`brickpoint-doctor.php` + manifest). **1.0.0** — first release.
- The theme was tested on WordPress 7.1.2 / PHP 8.3 and WordPress 7.1.1 / PHP 8.4 and reviewed against PHP 7.4 syntax rules; all templates, admin screens, AJAX endpoints and the 17 Elementor widgets were rendered during testing.
