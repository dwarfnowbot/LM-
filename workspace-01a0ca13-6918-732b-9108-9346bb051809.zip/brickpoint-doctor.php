<?php
/**
 * BrickPoint Doctor - theme & site diagnostics + emergency recovery.
 *
 * HOW TO USE
 * ----------
 * 1. Open this file in a text editor and change the key below to your own
 *    random string (at least 12 characters).
 * 2. Upload it to your WordPress folder (the folder that contains wp-config.php)
 *    using cPanel File Manager or FTP.
 * 3. Open it in your browser:  https://your-site.com/brickpoint-doctor.php?key=YOUR_KEY
 * 4. Read the report. If the theme is broken, use the "Repair" buttons.
 * 5. DELETE THIS FILE from the server when you are done.
 *
 * This file does not change anything unless you press a Repair button.
 *
 * @package BrickPoint
 */

// ---------------------------------------------------------------------------
// 1. SET YOUR OWN KEY HERE  (change this line before uploading!)
// ---------------------------------------------------------------------------
$BP_KEY = 'change-this-key-123';

// ---------------------------------------------------------------------------

$bp_key_ok = isset( $_GET['key'] ) && is_string( $_GET['key'] ) && hash_equals( $BP_KEY, $_GET['key'] );

if ( ! $bp_key_ok ) {
	http_response_code( 403 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo "BrickPoint Doctor\n\nAccess denied. Add ?key=YOUR_KEY to the URL (and set your own key inside this file first).\n";
	exit;
}

if ( 'change-this-key-123' === $BP_KEY ) {
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo "BrickPoint Doctor\n\nPlease open this file and change \$BP_KEY to your own random string before using it.\n";
	exit;
}

// ---------------------------------------------------------------------------
// Find WordPress (works from the WP root, or up to 3 folders above).
// ---------------------------------------------------------------------------
$bp_root = null;

$bp_candidates = array(
	rtrim( __DIR__, '/\\' ),
	dirname( rtrim( __DIR__, '/\\' ), 1 ),
	dirname( rtrim( __DIR__, '/\\' ), 2 ),
	dirname( rtrim( __DIR__, '/\\' ), 3 ),
);

foreach ( $bp_candidates as $bp_candidate ) {
	if ( $bp_candidate && file_exists( $bp_candidate . '/wp-config.php' ) && file_exists( $bp_candidate . '/wp-load.php' ) ) {
		$bp_root = $bp_candidate;
		break;
	}
}

$bp_theme_dir  = $bp_root ? $bp_root . '/wp-content/themes/brickpoint' : null;
$bp_wp_version = null;

if ( $bp_root && file_exists( $bp_root . '/wp-includes/version.php' ) ) {
	$bp_version_file = file_get_contents( $bp_root . '/wp-includes/version.php' );
	if ( preg_match( "/\\\$wp_version\s*=\s*'([^']+)'/", (string) $bp_version_file, $bp_m ) ) {
		$bp_wp_version = $bp_m[1];
	}
}

// ---------------------------------------------------------------------------
// Actions.
// ---------------------------------------------------------------------------
$bp_action  = isset( $_POST['bp_action'] ) ? preg_replace( '/[^a-z_]/', '', (string) $_POST['bp_action'] ) : '';
$bp_results = array();

if ( $bp_action && $bp_key_ok ) {
	if ( 'rename_theme' === $bp_action ) {
		if ( ! $bp_theme_dir || ! is_dir( $bp_theme_dir ) ) {
			$bp_results[] = array( 'bad', 'The brickpoint theme folder was not found - nothing to rename.' );
		} else {
			$bp_target = dirname( $bp_theme_dir ) . '/brickpoint-broken-' . gmdate( 'Ymd-His' );

			if ( @rename( $bp_theme_dir, $bp_target ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				$bp_results[] = array( 'good', 'Renamed to ' . basename( $bp_target ) . '. Now open ' . $bp_root . '/wp-admin/themes.php - WordPress will switch to a working theme automatically and your site will be back online.' );
			} else {
				$bp_results[] = array( 'bad', 'Could not rename the folder (permission denied). Delete it manually in cPanel File Manager, or use the "safe mode" action instead.' );
			}
		}
	}

	if ( 'safe_mode' === $bp_action ) {
		$wp_config = $bp_root . '/wp-config.php';

		if ( ! is_writable( $wp_config ) ) {
			$bp_results[] = array( 'bad', 'wp-config.php is not writable. Add this line yourself just above "That\'s all, stop editing!": define( \'BRICKPOINT_SAFE_MODE\', true );' );
		} else {
			$contents = file_get_contents( $wp_config );

			if ( false !== strpos( $contents, 'BRICKPOINT_SAFE_MODE' ) ) {
				$bp_results[] = array( 'good', 'Safe mode was already in wp-config.php. The theme is already running in safe mode.' );
			} else {
				copy( $wp_config, $wp_config . '.brickpoint-backup' );
				$line    = "define( 'BRICKPOINT_SAFE_MODE', true ); // BrickPoint theme safe mode - remove this line to restore the theme.\n";
				$updated = null;

				// 1) Normal case: just above the "That's all, stop editing!" marker.
				if ( preg_match( '/\/\*\s*That\'s all, stop editing/i', $contents ) ) {
					$updated = preg_replace( '/(\/\*\s*That\'s all, stop editing)/', $line . '$1', $contents, 1, $count );
				}

				// 2) No marker: insert straight above the line that loads wp-settings.php.
				if ( ! $updated && false !== strpos( $contents, 'wp-settings.php' ) ) {
					$updated = preg_replace( '/^([^\n]*wp-settings\.php[^\n]*)$/m', $line . '$1', $contents, 1, $count );

					if ( ! $count ) {
						$updated = null;
					}
				}

				// 3) Last resort.
				if ( ! $updated ) {
					$updated = $contents . "\n" . $line;
				}

				$placed_before_boot = false !== strpos( $updated, 'BRICKPOINT_SAFE_MODE' )
					&& ( false === strpos( $updated, 'wp-settings.php' ) || strpos( $updated, 'BRICKPOINT_SAFE_MODE' ) < strpos( $updated, 'wp-settings.php' ) );

				if ( $placed_before_boot && file_put_contents( $wp_config, $updated ) ) {
					$bp_results[] = array( 'good', 'Safe mode enabled (backup saved as wp-config.php.brickpoint-backup). The theme no longer loads, so your site and dashboard work again. Remove the line, or the backup file, to re-enable the theme.' );
				} else {
					if ( file_put_contents( $wp_config, $contents ) ) {
						$bp_results[] = array( 'bad', 'Safe mode could not be placed safely in wp-config.php, so nothing was changed. Please open wp-config.php and add this line yourself, just above the line that loads wp-settings.php: define( \'BRICKPOINT_SAFE_MODE\', true );' );
					} else {
						$bp_results[] = array( 'bad', 'Could not write wp-config.php - please add the line manually: define( \'BRICKPOINT_SAFE_MODE\', true );' );
					}
				}
			}
		}
	}

	if ( 'disable_theme' === $bp_action ) {
		// Try WordPress first (only works when the theme does not fatal).
		$switched = false;

		if ( $bp_root ) {
			try {
				if ( ! defined( 'WP_USE_THEMES' ) ) {
					define( 'WP_USE_THEMES', false );
				}
				require_once $bp_root . '/wp-load.php';

				$default = get_option( 'stylesheet' );
				$fallback = 'twentytwentyfive';

				foreach ( array( 'twentytwentyfive', 'twentytwentyfour', 'twentytwentythree', 'twentytwentytwo', 'twentytwentyone' ) as $candidate ) {
					if ( wp_get_theme( $candidate )->exists() ) {
						$fallback = $candidate;
						break;
					}
				}

				switch_theme( $fallback );
				$switched = true;
				$bp_results[] = array( 'good', 'Active theme changed from "' . $default . '" to "' . $fallback . '". Your site is back online.' );
			} catch ( \Throwable $e ) {
				$bp_results[] = array( 'bad', 'WordPress could not be loaded (' . $e->getMessage() . ') - using the "rename theme folder" action instead.' );
			}
		}

		if ( ! $switched ) {
			// Last resort: change the theme option directly in the database.
			$config = $bp_root ? file_get_contents( $bp_root . '/wp-config.php' ) : '';

			if ( preg_match( "/define\\(\\s*'DB_NAME'\\s*,\\s*'([^']*)'/", (string) $config, $m_name ) &&
				preg_match( "/define\\(\\s*'DB_USER'\\s*,\\s*'([^']*)'/", (string) $config, $m_user ) &&
				preg_match( "/define\\(\\s*'DB_PASSWORD'\\s*,\\s*'([^']*)'/", (string) $config, $m_pass ) &&
				preg_match( "/define\\(\\s*'DB_HOST'\\s*,\\s*'([^']*)'/", (string) $config, $m_host ) &&
				preg_match( "/\\\$table_prefix\\s*=\\s*'([^']+)'/", (string) $config, $m_prefix ) ) {

				if ( ! function_exists( 'mysqli_connect' ) ) {
					$bp_results[] = array( 'bad', 'The mysqli extension is not available on this server, so the theme cannot be switched automatically. Use the "rename theme folder" action.' );
				} else {
					$host_parts = explode( ':', $m_host[1] );
					$link       = @mysqli_connect( $host_parts[0], $m_user[1], $m_pass[1], $m_name[1], isset( $host_parts[1] ) ? (int) $host_parts[1] : 3306 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

					if ( ! $link ) {
						$bp_results[] = array( 'bad', 'Could not connect to the database: ' . mysqli_connect_error() . '. Use the "rename theme folder" action instead.' );
					} else {
						$fallback = 'twentytwentyfive';
						$table    = $m_prefix[1] . 'options';

						foreach ( array( 'twentytwentyfive', 'twentytwentyfour', 'twentytwentythree', 'twentytwentytwo' ) as $candidate ) {
							if ( is_dir( $bp_root . '/wp-content/themes/' . $candidate ) ) {
								$fallback = $candidate;
								break;
							}
						}

						$stmt = mysqli_prepare( $link, "UPDATE `{$table}` SET option_value = ? WHERE option_name IN ('template', 'stylesheet')" );

						if ( $stmt ) {
							mysqli_stmt_bind_param( $stmt, 's', $fallback );
							mysqli_stmt_execute( $stmt );
							$affected = mysqli_stmt_affected_rows( $stmt );
							mysqli_stmt_close( $stmt );

							$bp_results[] = $affected
								? array( 'good', 'Theme switched to "' . $fallback . '" directly in the database. Reload your site - it is back online.' )
								: array( 'bad', 'The database was reachable but no rows changed. Try the "rename theme folder" action.' );
						}

						mysqli_close( $link );
					}
				}
			} else {
				$bp_results[] = array( 'bad', 'Could not read the database details from wp-config.php. Use the "rename theme folder" action instead.' );
			}
		}
	}
}

// ---------------------------------------------------------------------------
// Report.
// ---------------------------------------------------------------------------
$bp_files_ok      = 0;
$bp_files_missing = array();
$bp_files_bad     = array();
$bp_file_count    = 0;
$bp_manifest      = json_decode( file_get_contents( __DIR__ . '/brickpoint-doctor.manifest.json' ), true );

if ( ! is_array( $bp_manifest ) ) {
	$bp_manifest = array();
}

$bp_installed_version = '';
$bp_style_file        = $bp_theme_dir . '/style.css';

if ( $bp_theme_dir && is_readable( $bp_style_file ) ) {
	$bp_style_head = (string) file_get_contents( $bp_style_file, false, null, 0, 8192 );

	if ( preg_match( '/^[ \t\/*#]*Version:\s*([0-9.]+)/mi', $bp_style_head, $bp_ver_match ) ) {
		$bp_installed_version = $bp_ver_match[1];
	}
}

$bp_theme_files = array();

if ( $bp_theme_dir && is_dir( $bp_theme_dir ) ) {
	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $bp_theme_dir, FilesystemIterator::SKIP_DOTS )
	);

	foreach ( $iterator as $bp_file ) {
		if ( $bp_file->isFile() ) {
			$bp_theme_files[ str_replace( '\\', '/', substr( $bp_file->getPathname(), strlen( $bp_theme_dir ) + 1 ) ) ] = $bp_file->getSize();
		}
	}
}

foreach ( $bp_manifest as $bp_rel => $bp_expected ) {
	$bp_file_count++;

	if ( ! isset( $bp_theme_files[ $bp_rel ] ) ) {
		$bp_files_missing[] = $bp_rel;
		continue;
	}

	$bp_actual = $bp_theme_files[ $bp_rel ];

	if ( $bp_expected > 200 && $bp_actual < (int) ( $bp_expected * 0.9 ) ) {
		$bp_files_bad[] = $bp_rel . ' (' . number_format( $bp_actual ) . ' bytes, official release has ' . number_format( $bp_expected ) . ' - truncated upload or an older file)';
		continue;
	}

	$bp_files_ok++;
}

// Extra check on PHP files that are present but may be damaged.
$bp_php_bad = array();

if ( $bp_theme_files ) {
	foreach ( $bp_theme_files as $bp_rel => $bp_size ) {
		if ( substr( $bp_rel, -4 ) !== '.php' ) {
			continue;
		}

		$bp_path = $bp_theme_dir . '/' . $bp_rel;
		$source  = file_get_contents( $bp_path );

		// A healthy PHP file never ends in the middle of a statement.
		$trimmed = rtrim( (string) $source );

		if ( '' === $trimmed || substr( $trimmed, -1 ) === ',' || substr( $trimmed, -1 ) === '(' || substr( $trimmed, -1 ) === '=' ) {
			$bp_php_bad[] = $bp_rel . ' (ends unexpectedly)';
			continue;
		}

		if ( substr_count( $source, '{' ) !== substr_count( $source, '}' ) ) {
			$bp_php_bad[] = $bp_rel . ' (unbalanced braces - file is incomplete)';
			continue;
		}

		if ( function_exists( 'exec' ) ) {
			$output = array();
			$code   = 127;
			@exec( 'php -l ' . escapeshellarg( $bp_path ) . ' 2>&1', $output, $code ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

			if ( 0 === $code ) {
				continue;
			}

			if ( 127 !== $code ) {
				$bp_php_bad[] = $bp_rel . ' (' . trim( implode( ' ', (array) $output ) ) . ')';
			}
		}
	}
}

// WordPress load test (survives a broken theme).
$bp_wp_load    = null;
$bp_active     = '-';
$bp_admin_url  = $bp_root ? '/' : '/';
$bp_theme_info = array();

try {
	if ( $bp_root ) {
		if ( ! defined( 'WP_USE_THEMES' ) ) {
			define( 'WP_USE_THEMES', false );
		}

		require_once $bp_root . '/wp-load.php';

		$bp_wp_load   = true;
		$bp_active    = get_option( 'stylesheet' );
		$bp_admin_url = admin_url( 'themes.php' );

		foreach ( (array) wp_get_themes() as $bp_slug => $bp_theme ) {
			$bp_theme_info[] = $bp_slug . ( $bp_theme->errors() ? ' (broken)' : '' ) . ( $bp_slug === $bp_active ? ' <- active' : '' );
		}
	}
} catch ( \Throwable $bp_error ) {
	$bp_wp_load = false;
	$bp_wp_error = $bp_error->getMessage();
}

$bp_debug_log  = $bp_root ? $bp_root . '/wp-content/debug.log' : '';
$bp_log_lines  = array();

if ( $bp_debug_log && file_exists( $bp_debug_log ) && is_readable( $bp_debug_log ) ) {
	$bp_log_lines = array_slice( file( $bp_debug_log, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ), -40 );
}

header( 'Content-Type: text/html; charset=utf-8' );
header( 'X-Robots-Tag: noindex, nofollow' );
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="robots" content="noindex, nofollow" />
<title>BrickPoint Doctor</title>
<style>
	body { font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; background:#0e0f11; color:#e9e5de; margin:0; padding:34px 18px 80px; line-height:1.6; }
	.wrap { max-width: 1000px; margin: 0 auto; }
	h1 { font-size: 1.7rem; margin: 0 0 .2em; color:#fff; }
	h2 { font-size: 1.15rem; margin: 34px 0 12px; color:#fff; border-bottom:1px solid rgba(255,255,255,.14); padding-bottom:8px; }
	.lead { color:#bdb7ad; margin-top:0; }
	table { width:100%; border-collapse: collapse; font-size:.92rem; }
	td, th { text-align:left; padding:9px 10px; border-bottom:1px solid rgba(255,255,255,.09); vertical-align: top; }
	th { width: 34%; color:#cfc9c0; font-weight:600; }
	.ok   { color:#5ee08a; }
	.bad  { color:#ff8d7a; }
	.warn { color:#ffd479; }
	code, pre { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size:.85rem; }
	pre { background:#16181c; border:1px solid rgba(255,255,255,.12); border-radius:10px; padding:14px; overflow:auto; max-height:340px; }
	.box { background:#16181c; border:1px solid rgba(255,255,255,.12); border-radius:12px; padding:18px 20px; margin:14px 0; }
	.box.good { border-color:#2f7d52; }
	.box.bad  { border-color:#8f2323; }
	button { font:inherit; font-weight:600; padding:11px 18px; border-radius:9px; border:1px solid transparent; background:#c1440e; color:#fff; cursor:pointer; margin:0 8px 8px 0; }
	button.alt { background:#2a2d33; border-color:rgba(255,255,255,.18); }
	button:hover { filter:brightness(1.1); }
	form { display:inline; }
	.small { font-size:.85rem; color:#8f8a82; }
	ul { margin: 6px 0 0 18px; }
</style>
</head>
<body>
<div class="wrap">
	<h1>BrickPoint Doctor</h1>
	<p class="lead">Reports the state of your WordPress installation and the BrickPoint theme. Nothing is changed unless you press a repair button. <strong>Delete this file when you are finished.</strong></p>

	<?php foreach ( $bp_results as $bp_result ) : ?>
		<div class="box <?php echo 'good' === $bp_result[0] ? 'good' : 'bad'; ?>">
			<strong class="<?php echo 'good' === $bp_result[0] ? 'ok' : 'bad'; ?>"><?php echo 'good' === $bp_result[0] ? 'Done:' : 'Problem:'; ?></strong>
			<?php echo htmlspecialchars( $bp_result[1], ENT_QUOTES, 'UTF-8' ); ?>
		</div>
	<?php endforeach; ?>

	<h2>1. Server</h2>
	<table>
		<tr><th>PHP version</th><td class="<?php echo version_compare( PHP_VERSION, '7.4', '>=' ) ? 'ok' : 'bad'; ?>"><?php echo htmlspecialchars( PHP_VERSION ); ?> <?php echo version_compare( PHP_VERSION, '7.4', '>=' ) ? '(supported)' : '- BrickPoint needs PHP 7.4 or newer. Ask your host to change the PHP version.'; ?></td></tr>
		<tr><th>PHP memory limit</th><td><?php echo htmlspecialchars( (string) ini_get( 'memory_limit' ) ); ?></td></tr>
		<tr><th>Max execution time</th><td><?php echo htmlspecialchars( (string) ini_get( 'max_execution_time' ) ); ?> sec</td></tr>
		<tr><th>Upload max filesize</th><td><?php echo htmlspecialchars( (string) ini_get( 'upload_max_filesize' ) ); ?> | post_max_size <?php echo htmlspecialchars( (string) ini_get( 'post_max_size' ) ); ?></td></tr>
		<tr><th>Extensions</th><td><?php echo class_exists( 'ZipArchive' ) ? '<span class="ok">zip ok</span>' : '<span class="bad">zip MISSING (theme uploads will fail)</span>'; ?> | <?php echo extension_loaded( 'mbstring' ) ? 'mbstring ok' : '<span class="warn">mbstring missing</span>'; ?> | <?php echo extension_loaded( 'mysqli' ) ? 'mysqli ok' : 'mysqli missing'; ?> | <?php echo extension_loaded( 'curl' ) ? 'curl ok' : 'curl missing'; ?></td></tr>
		<tr><th>Disk free space</th><td><?php $free = $bp_root ? @disk_free_space( $bp_root ) : false; echo $free ? htmlspecialchars( size_format( $free ) ) : 'unknown'; ?></td></tr>
		<tr><th>exec() available</th><td><?php echo function_exists( 'exec' ) ? 'yes (file syntax is being verified)' : 'no (only size/structure checks)'; ?></td></tr>
	</table>

	<h2>2. WordPress</h2>
	<table>
		<tr><th>WordPress folder</th><td><?php echo $bp_root ? htmlspecialchars( $bp_root ) : '<span class="bad">wp-config.php / wp-load.php not found from this file\'s location</span>'; ?></td></tr>
		<tr><th>WordPress version</th><td><?php echo $bp_wp_version ? htmlspecialchars( $bp_wp_version ) : 'unknown'; ?></td></tr>
		<tr><th>WordPress loads?</th><td>
			<?php if ( true === $bp_wp_load ) : ?>
				<span class="ok">yes - dashboard is reachable</span>
			<?php elseif ( false === $bp_wp_load ) : ?>
				<span class="bad">no - <?php echo htmlspecialchars( (string) $bp_wp_error ); ?></span>
			<?php else : ?>
				unknown
			<?php endif; ?>
		</td></tr>
		<tr><th>Active theme</th><td><strong><?php echo htmlspecialchars( (string) $bp_active ); ?></strong></td></tr>
		<tr><th>Themes installed</th><td><?php echo htmlspecialchars( implode( ', ', $bp_theme_info ) ); ?></td></tr>
	</table>

	<h2>3. BrickPoint theme files</h2>
	<?php if ( ! $bp_theme_dir || ! is_dir( $bp_theme_dir ) ) : ?>
		<div class="box bad">The folder <code>wp-content/themes/brickpoint</code> was not found. If you already installed the theme, the upload did not complete - install it again (or extract the zip directly inside <code>wp-content/themes/</code> with cPanel File Manager).</div>
	<?php else : ?>
		<table>
			<tr><th>Folder</th><td><?php echo htmlspecialchars( $bp_theme_dir ); ?></td></tr>
			<tr><th>Files found</th><td><?php echo number_format( count( $bp_theme_files ) ); ?> (expected <?php echo number_format( count( $bp_manifest ) ); ?>)</td></tr>
			<tr><th>Installed version</th><td><strong><?php echo $bp_installed_version ? htmlspecialchars( $bp_installed_version ) : 'unknown'; ?></strong><?php if ( '1.0.4' !== $bp_installed_version ) : ?> <span class="bad">- the doctor expects 1.0.4, install the current brickpoint.zip</span><?php else : ?> <span class="ok">- current</span><?php endif; ?></td></tr>
			<tr><th>Files matching the official release</th><td class="<?php echo $bp_files_ok === $bp_file_count ? 'ok' : 'bad'; ?>"><?php echo number_format( $bp_files_ok ); ?> / <?php echo number_format( $bp_file_count ); ?> <span class="small">(files that differ are either older 1.0.0/1.0.1 files or were changed after upload)</span></td></tr>
			<tr><th>Missing files</th><td class="<?php echo $bp_files_missing ? 'bad' : 'ok'; ?>">
				<?php if ( ! $bp_files_missing ) : ?>
					none
				<?php else : ?>
					<ul><?php foreach ( $bp_files_missing as $bp_f ) : ?><li><?php echo htmlspecialchars( $bp_f ); ?></li><?php endforeach; ?></ul>
				<?php endif; ?>
			</td></tr>
			<tr><th>Older / truncated / changed files</th><td class="<?php echo ( $bp_files_bad || $bp_php_bad ) ? 'bad' : 'ok'; ?>">
				<?php if ( ! $bp_files_bad && ! $bp_php_bad ) : ?>
					none
				<?php else : ?>
					<ul>
						<?php foreach ( array_merge( $bp_files_bad, $bp_php_bad ) as $bp_f ) : ?>
							<li><?php echo htmlspecialchars( $bp_f ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</td></tr>
		</table>
	<?php endif; ?>

	<h2>4. Repair</h2>
	<p class="small">
		<strong>Preferred order:</strong> 1) rename the theme folder &rarr; 2) switch theme &rarr; 3) safe mode.
		After a repair, reinstall BrickPoint from a fresh download before re-activating it.
	</p>

	<form method="post" onsubmit="return confirm('Rename wp-content/themes/brickpoint ? Your site will fall back to another theme.');">
		<input type="hidden" name="bp_action" value="rename_theme" />
		<button type="submit">1. Rename the BrickPoint theme folder</button>
	</form>

	<form method="post" onsubmit="return confirm('Switch the active theme to a default WordPress theme?');">
		<input type="hidden" name="bp_action" value="disable_theme" />
		<button type="submit" class="alt">2. Switch to a default theme</button>
	</form>

	<form method="post" onsubmit="return confirm('Add BRICKPOINT_SAFE_MODE to wp-config.php ? The theme will stop loading (reversible).');">
		<input type="hidden" name="bp_action" value="safe_mode" />
		<button type="submit" class="alt">3. Enable theme safe mode (wp-config.php)</button>
	</form>

	<?php if ( $bp_wp_load ) : ?>
		<p class="small">Dashboard: <a style="color:#e2571e" href="<?php echo htmlspecialchars( $bp_admin_url ); ?>"><?php echo htmlspecialchars( $bp_admin_url ); ?></a> &middot; Appearance &rarr; Themes to activate a working theme.</p>
	<?php endif; ?>

	<h2>5. Recent debug.log entries</h2>
	<?php if ( ! $bp_log_lines ) : ?>
		<p class="small">No readable <code>wp-content/debug.log</code> (WP_DEBUG_LOG is probably off - that is fine).</p>
	<?php else : ?>
		<pre><?php echo htmlspecialchars( implode( "\n", $bp_log_lines ) ); ?></pre>
	<?php endif; ?>

	<p class="small" style="margin-top:34px">BrickPoint Doctor &middot; delete this file (and <code>brickpoint-doctor.manifest.json</code>) when you are finished.</p>
</div>
</body>
</html>
