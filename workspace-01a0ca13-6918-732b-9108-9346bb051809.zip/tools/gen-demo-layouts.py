#!/usr/bin/env python3
"""
Generate the BrickPoint demo Elementor layouts.

Output: brickpoint/demo/layouts/<page-slug>.json

Each file is a full Elementor elements array (list of sections) for one page.
Image / video / URL values are written as placeholders that
inc/demo-content.php replaces with real attachment IDs, URLs and permalinks
at import time:

    {{IMG_URL:key}}  {{IMG_ID:key}}  {{VID_URL:key}}  {{VID_ID:key}}  {{URL:slug}}

Run:  python3 tools/gen-demo-layouts.py
"""

import json
import os
import random

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'brickpoint', 'demo', 'layouts')

SAND = '#f6f1ea'
WHITE = '#ffffff'
INK = '#0e0f11'
BRICK = '#c1440e'
MUTED = '#4a4a4a'


def uid():
    return ''.join(random.choice('0123456789abcdef') for _ in range(7))


def widget(wtype, settings=None):
    return {
        "id": uid(),
        "elType": "widget",
        "widgetType": wtype,
        "settings": settings or {},
        "elements": [],
        "isInner": False,
    }


def column(elements, size=100):
    return {
        "id": uid(),
        "elType": "column",
        "settings": {"_column_size": size, "_inline_size": None},
        "elements": elements,
        "isInner": False,
    }


def section(columns, bg=None, pad=("80", "24", "80", "24"), full=False, extra=None):
    settings = {"layout": "full_width" if full else "boxed", "gap": "extended"}

    if not full:
        settings["content_width"] = {"unit": "px", "size": 1240, "sizes": []}

    if pad:
        settings["padding"] = {
            "unit": "px",
            "top": pad[0], "right": pad[1], "bottom": pad[2], "left": pad[3],
            "isLinked": False,
        }

    if bg:
        settings["background_background"] = "classic"
        settings["background_color"] = bg

    if extra:
        settings.update(extra)

    return {
        "id": uid(),
        "elType": "section",
        "settings": settings,
        "elements": columns,
        "isInner": False,
    }


def one(widgets, **kw):
    return section([column(list(widgets))], **kw)


def two(left, right, sizes=(50, 50), **kw):
    return section([column(list(left), sizes[0]), column(list(right), sizes[1])], **kw)


# --------------------------------------------------------------------- helpers


def img(key):
    return {"url": "{{IMG_URL:%s}}" % key, "id": "{{IMG_ID:%s}}" % key}


def vid(key):
    return {"url": "{{VID_URL:%s}}" % key, "id": "{{VID_ID:%s}}" % key}


def url(slug):
    return "{{URL:%s}}" % slug


def heading(text, tag="h2", align="left", color=None):
    settings = {"title": text, "header_size": tag, "align": align}
    if color:
        settings["title_color"] = color
    return widget("heading", settings)


def rich(html, align="left", color=None):
    settings = {"editor": html, "align": align}
    if color:
        settings["text_color"] = color
    return widget("text-editor", settings)


def button(label, link, align="left", size="md", color=None, bg=None):
    settings = {
        "text": label,
        "link": {"url": link, "is_external": "", "nofollow": "", "custom_attributes": ""},
        "align": align,
        "size": size,
    }
    if color:
        settings["button_text_color"] = color
    if bg:
        settings["background_color"] = bg
    return widget("button", settings)


def iconlist(items, color=BRICK):
    return widget("icon-list", {
        "icon_list": [
            {
                "_id": uid(),
                "text": item,
                "selected_icon": {"value": "fas fa-check-circle", "library": "fa-solid"},
            }
            for item in items
        ],
        "icon_color": color,
        "space_between": {"unit": "px", "size": 12, "sizes": []},
    })


# ------------------------------------------------------- BrickPoint widgets


def bp_heading(eyebrow, title, text, align="left", tag="h2"):
    return widget("bp_section_heading", {
        "head_eyebrow": eyebrow,
        "head_title": title,
        "head_text": text,
        "head_align": align,
        "head_tag": tag,
    })


def bp_product_grid(**kw):
    settings = {
        "category": "",
        "featured_only": "",
        "limit": 6,
        "orderby": "date",
        "order": "DESC",
        "pagination": "none",
        "card_style": "default",
        "hover_effect": "lift",
        "image_ratio": "4-3",
        "columns": 3,
        "columns_tablet": 2,
        "columns_mobile": 1,
        "gap": {"unit": "px", "size": 28, "sizes": []},
        "show_excerpt": "yes",
        "show_price": "yes",
        "show_price_label": "yes",
        "show_details_btn": "yes",
        "show_whatsapp": "yes",
    }
    settings.update(kw)
    return widget("bp_product_grid", settings)


def bp_video_grid(**kw):
    settings = {
        "category": "",
        "featured_only": "",
        "limit": 6,
        "orderby": "date",
        "pagination": "none",
        "show_filters": "",
        "image_fit": "cover",
        "hover": "zoom",
        "columns": 3,
        "columns_tablet": 2,
        "columns_mobile": 1,
        "gap": {"unit": "px", "size": 28, "sizes": []},
        "show_title": "yes",
        "show_desc": "yes",
        "show_cat": "yes",
        "show_duration": "yes",
        "show_date": "yes",
        "show_play": "yes",
        "show_badge": "yes",
        "show_view_btn": "yes",
    }
    settings.update(kw)
    return widget("bp_video_grid", settings)


def bp_project_grid(**kw):
    settings = {
        "category": "",
        "featured_only": "",
        "limit": 6,
        "orderby": "menu_order",
        "show_meta": "yes",
        "columns": 3,
        "columns_tablet": 2,
        "columns_mobile": 1,
        "gap": {"unit": "px", "size": 28, "sizes": []},
    }
    settings.update(kw)
    return widget("bp_project_grid", settings)


def bp_location_cards(**kw):
    settings = {
        "limit": -1,
        "show_address": "yes",
        "show_hours": "yes",
        "show_buttons": "yes",
        "show_video": "yes",
        "show_products": "yes",
        "head_eyebrow": "",
        "head_title": "",
        "head_text": "",
        "head_align": "left",
        "head_tag": "h2",
        "columns": 2,
        "columns_tablet": 2,
        "columns_mobile": 1,
        "gap": {"unit": "px", "size": 28, "sizes": []},
    }
    settings.update(kw)
    return widget("bp_location_cards", settings)


def bp_categories(**kw):
    settings = {
        "home_only": "yes",
        "limit": 12,
        "show_whatsapp": "yes",
        "show_count": "yes",
        "style": "card",
        "image_ratio": "4-3",
        "head_eyebrow": "",
        "head_title": "",
        "head_text": "",
        "head_align": "left",
        "head_tag": "h2",
        "columns": 4,
        "columns_tablet": 3,
        "columns_mobile": 2,
        "gap": {"unit": "px", "size": 24, "sizes": []},
    }
    settings.update(kw)
    return widget("bp_product_categories", settings)


def bp_stats(items, **kw):
    settings = {
        "head_eyebrow": "",
        "head_title": "",
        "head_text": "",
        "head_align": "left",
        "head_tag": "h2",
        "items": [
            {
                "_id": uid(),
                "icon": icon,
                "title": title,
                "text": text,
                "value": value,
            }
            for (icon, title, text, value) in items
        ],
    }
    settings.update(kw)
    return widget("bp_stats", settings)


def bp_whatsapp(label, message="", context="general", align="left", style="whatsapp", size="lg"):
    return widget("bp_whatsapp_button", {
        "label": label,
        "context": context,
        "message": message,
        "style": style,
        "size": size,
        "show_icon": "yes",
        "show_phone": "yes",
        "full_width": "",
        "align": align,
    })


def bp_contact_form(head, subtext, button_label="Send Inquiry", context="Website inquiry form"):
    return widget("bp_contact_form", {
        "heading": head,
        "subtext": subtext,
        "button": button_label,
        "context": context,
    })


def bp_ss7_showcase(**kw):
    settings = {
        "eyebrow": "SS7 Bricks",
        "title": "The Strength Behind Every Structure",
        "text": "SS7 Bricks are produced and stacked with a focus on uniform size, clean edges and "
                "consistent strength. Ask us for current sizes, rates and availability for your project.",
        "image": img("brick-ss7"),
        "gallery": [img("brick-standard"), img("project-boundary")],
        "video_file": vid("demo-brick-stacking"),
        "btn1_label": "View SS7 Bricks",
        "btn1_link": {"url": url("ss7-bricks"), "is_external": "", "nofollow": ""},
        "quote_label": "Request Quotation",
        "whatsapp_label": "Ask about SS7 on WhatsApp",
        "specs": [
            {"_id": uid(), "label": "Material", "value": "Fired clay brick"},
            {"_id": uid(), "label": "Standard use", "value": "Load-bearing walls, grey structure, boundary walls"},
            {"_id": uid(), "label": "Supply", "value": "Bulk loads — confirm sizes and rates on inquiry"},
        ],
        "highlights": "Uniform size and clean edges\nConsistent strength across the stack\nStacked and loaded with care\nBulk supply for projects and homes",
        "media_side": "right",
        "animation": "depth",
        "section_bg": INK,
        "text_color": WHITE,
    }
    settings.update(kw)
    return widget("bp_ss7_showcase", settings)


def bp_hero(**kw):
    settings = {
        "eyebrow": "Bricks • Cement • Crush • Sand • Steel",
        "title": "Building Strength.\nDelivering Quality.\nShaping Tomorrow.",
        "text": "BrickPoint supplies premium bricks and reliable construction materials for contractors, "
                "builders, developers and home owners — with one WhatsApp line for quotations and orders.",
        "btn1_label": "Explore Products",
        "btn1_link": {"url": url("products"), "is_external": "", "nofollow": ""},
        "btn2_label": "Request a Quote",
        "btn2_link": {"url": url("contact"), "is_external": "", "nofollow": ""},
        "btn3_whatsapp": "yes",
        "wa_label": "WhatsApp Us",
        "video_file": vid("demo-brick-yard"),
        "poster": img("hero-video-poster"),
        "badge": "Demo video — replace with your own",
        "video_radius": {"unit": "px", "size": 18, "sizes": []},
        "video_opacity": {"unit": "%", "size": 55, "sizes": []},
        "autoplay": "yes",
        "show_toggle": "yes",
        "ss7_enable": "yes",
        "ss7_image": img("brick-ss7"),
        "ss7_depth": "medium",
        "bg_color": INK,
    }
    settings.update(kw)
    return widget("bp_hero", settings)


def cta_section(title, text, wa_label, message, contact_url=None):
    return one(
        [
            heading(title, "h2", "center", WHITE),
            rich('<p style="color:#d8d3cb;text-align:center;">%s</p>' % text),
            bp_whatsapp(wa_label, message=message, align="center"),
            button("Request a Quote", contact_url or url("contact"), align="center", bg=BRICK, color=WHITE),
        ],
        bg=INK,
    )


# ------------------------------------------------------------------ the pages


def home():
    return [
        section([column([bp_hero()])], full=True, pad=None),
        one([
            bp_heading("Who we are", "BrickPoint supplies the materials that hold projects together",
                       "BrickPoint is a construction-materials supplier providing bricks and building materials "
                       "for contractors, builders, developers, architects and individual customers. Our production "
                       "companies are Masha Allah Bricks Company, Fine Bricks Company and SS7 Bricks."),
            bp_stats([
                ("shield", "Quality-focused supply", "Materials sourced from our own production and trusted suppliers.", ""),
                ("truck", "Reliable delivery", "Loading and dispatch coordinated with your site schedule.", ""),
                ("factory", "Multiple production locations", "Ram Thaman, Raja Jang and Sattoki production sites.", ""),
                ("layers", "Construction material solutions", "From bricks and cement to steel, crush, sand and finishing items.", ""),
            ]),
            button("More about BrickPoint", url("about-us"), bg=BRICK, color=WHITE),
        ], bg=SAND),
        one([
            bp_heading("What we supply", "Materials for every stage of construction",
                       "Explore the categories we supply most often. Every category page shows the products, "
                       "specifications and a direct WhatsApp line to our team."),
            bp_categories(limit=8, home_only="", columns=4, columns_tablet=3, columns_mobile=2),
        ]),
        one([
            bp_heading("Featured products", "Popular materials, ready for your site",
                       "Demo products are installed so you can see how the grid looks. Edit or delete them in "
                       "WordPress → Products."),
            bp_product_grid(featured_only="yes", limit=6, pagination="numbers"),
            button("View all products", url("products"), align="center", bg=BRICK, color=WHITE),
        ], bg=SAND),
        section([column([bp_ss7_showcase()])], full=True, pad=None),
        one([
            bp_heading("Videos", "See the material before you order",
                       "Short walkthroughs of bricks, loading and stock — replace the demo clips with your own."),
            bp_video_grid(limit=3),
            button("All videos", url("videos"), align="center", bg=BRICK, color=WHITE),
        ]),
        one([
            bp_heading("Where to find us", "Production sites and sales office",
                       "Visit or call before loading. Google Maps links open the exact location."),
            bp_location_cards(limit=4),
        ], bg=SAND),
        one([
            bp_heading("Request a quotation", "Send your material list, quantity and delivery location",
                       "Our team replies with availability and a rate. For the fastest response use WhatsApp.", "center"),
            bp_contact_form("Request a quotation", "Share your material list, quantity and delivery location.", "Send Inquiry", "Home page"),
        ], bg=WHITE),
    ]


def about():
    return [
        one([
            bp_heading("About us", "A construction-materials supplier built around reliable supply",
                       "BrickPoint delivers premium bricks and building materials for projects of every size — "
                       "from a single house to multi-site supply."),
            rich(
                "<p>BrickPoint is a construction-materials supplier based in Punjab, Pakistan. We supply bricks "
                "and the materials a project needs: cement, crush, sand, steel, pipes, construction chemicals "
                "and finishing items.</p>"
                "<p>Our production companies are <strong>Masha Allah Bricks Company</strong>, "
                "<strong>Fine Bricks Company</strong> and <strong>SS7 Bricks</strong>. Materials come from our own "
                "production and from trusted suppliers in the same supply chain.</p>"
                "<p><em>Edit this text with your own verified company story, milestones and team details. "
                "BrickPoint never publishes claims that cannot be confirmed.</em></p>"
            ),
        ]),
        one([
            bp_heading("How we work", "Straightforward material supply",
                       "Clear communication from inquiry to delivery."),
            bp_stats([
                ("check", "Share your list", "Send material, quantity and delivery location on WhatsApp or through the form.", ""),
                ("clock", "Confirm rate & availability", "Our sales team confirms current rates, sizes and loading time.", ""),
                ("truck", "Loading & dispatch", "Bricks and materials are loaded at the production site for your schedule.", ""),
                ("shield", "Consistent quality", "Materials are checked and stacked with care on every consignment.", ""),
            ]),
        ], bg=SAND),
        one([
            bp_heading("Management", "Talk to the team", "Your first point of contact for quotations and supply.", "center"),
            rich('<p style="text-align:center;">Chief Executive Officer and Sales Manager details are editable in '
                 'Appearance → Customize → BrickPoint.</p>', align="center"),
            bp_whatsapp("WhatsApp the sales team", message="Assalam-o-Alaikum BrickPoint, I would like to discuss a material requirement.", align="center"),
        ]),
        one([
            bp_heading("Our locations", "Production sites and office", "Call or WhatsApp before visiting to confirm loading times."),
            bp_location_cards(limit=4),
        ], bg=SAND),
    ]


def products():
    return [
        one([
            bp_heading("Products", "Bricks and construction materials we supply",
                       "Prices and availability are confirmed on inquiry. Demo products are installed so the grids, "
                       "specifications and WhatsApp buttons are visible — edit or delete them in WordPress → Products."),
            bp_product_grid(limit=9, pagination="numbers", orderby="menu_order"),
        ]),
        one([
            bp_heading("Browse by category", "Every category, one supply line", ""),
            bp_categories(limit=15, home_only="", columns=4, columns_tablet=3, columns_mobile=2),
        ], bg=SAND),
        cta_section("Need a rate for a full material list?",
                    "Send your list on WhatsApp and our team will confirm rates and availability.",
                    "WhatsApp your material list",
                    "Assalam-o-Alaikum BrickPoint, I would like rates for a material list."),
    ]


def product_categories():
    return [
        one([
            bp_heading("Product categories", "Find materials by category",
                       "Every category page lists the products we supply, their specifications and a WhatsApp "
                       "inquiry button."),
            bp_categories(limit=15, home_only="", columns=4, columns_tablet=3, columns_mobile=2),
        ]),
        one([
            bp_heading("Bricks and blocks", "Our own production", "SS7 Bricks, clay bricks and block supply."),
            bp_product_grid(category="bricks", limit=3, orderby="menu_order"),
        ], bg=SAND),
        one([
            bp_heading("All products", "Everything in one place", ""),
            bp_product_grid(limit=9, pagination="load_more", orderby="menu_order"),
            button("Open the products page", url("products"), align="center", bg=BRICK, color=WHITE),
        ]),
    ]


def ss7():
    return [
        section([column([bp_ss7_showcase()])], full=True, pad=None),
        one([
            bp_heading("SS7 bricks", "Consistent size, clean edges, dependable strength",
                       "SS7 Bricks are produced at our own bhattas and supplied in bulk for grey structure, "
                       "boundary walls and general masonry work."),
            bp_product_grid(category="ss7-bricks", limit=6, orderby="menu_order"),
        ]),
        one([
            bp_heading("Watch SS7 bricks", "Stacking, loading and quality checks",
                       "Replace the demo clips with footage from your own production."),
            bp_video_grid(category="ss7-bricks", limit=3),
            button("More videos", url("videos"), align="center", bg=BRICK, color=WHITE),
        ], bg=SAND),
        one([
            bp_heading("Order SS7 bricks", "Confirm sizes, quantity and delivery",
                       "Send your requirement and we will confirm the current rate and loading schedule.", "center"),
            bp_whatsapp("Ask about SS7 Bricks", message="Assalam-o-Alaikum BrickPoint, I would like a quotation for SS7 Bricks.", align="center"),
            widget("spacer", {"space": {"unit": "px", "size": 20, "sizes": []}}),
            bp_contact_form("SS7 Bricks inquiry", "Quantity, delivery location and preferred loading date.", "Send Inquiry", "SS7 Bricks page"),
        ]),
    ]


def construction_materials():
    return [
        one([
            bp_heading("Construction materials", "One supply line for the whole site",
                       "Cement, crush, sand, steel, pipes, construction chemicals, insulation, cables, paints and "
                       "finishing items — ordered together and delivered with your bricks."),
            bp_categories(limit=15, home_only="", columns=4, columns_tablet=3, columns_mobile=2),
        ]),
        one([
            bp_heading("Materials we supply", "Popular items", "Rates and availability are confirmed on inquiry."),
            bp_product_grid(limit=9, orderby="menu_order", pagination="load_more"),
        ], bg=SAND),
        one([
            bp_heading("Project supply", "Grey structure to finishing",
                       "Share your material schedule and we will work through the list with you."),
            iconlist([
                "Bricks and blocks from our own production",
                "Cement, crush, sand and steel in bulk",
                "Pipes, electrical items and construction chemicals",
                "Insulation, cables, paints, lights and switches",
                "Delivery coordination with your site team",
            ]),
            bp_whatsapp("Send your material list", message="Assalam-o-Alaikum BrickPoint, I need a quotation for construction materials."),
        ]),
    ]


def projects():
    return [
        one([
            bp_heading("Projects", "Material supply for homes and commercial sites",
                       "These are demo project entries. Replace them with your own work and photos — every card is "
                       "editable in WordPress → Projects."),
            bp_project_grid(limit=12, orderby="menu_order", columns=3),
        ]),
        one([
            rich('<p><strong>Note on project visuals:</strong> demo project cards are marked “Illustrative '
                 'construction reference”. Replace them with your own project details and photos, and never '
                 'claim supply to a named project, developer or housing society unless it can be confirmed.</p>',
                 color=MUTED),
        ], bg=SAND, pad=("48", "24", "48", "24")),
        cta_section("Building a project and need materials?",
                    "Send the material list and delivery schedule — we will confirm rates and loading times.",
                    "Discuss your project",
                    "Assalam-o-Alaikum BrickPoint, I would like to discuss material supply for a project."),
    ]


def videos():
    return [
        one([
            bp_heading("Videos", "See the material and the loading before you order",
                       "Demo clips are installed with the theme so the page is never empty. Replace them with your "
                       "own videos in WordPress → Videos (self-hosted MP4, YouTube or Vimeo)."),
            bp_video_grid(limit=12, show_filters="yes", columns=3, pagination="load_more"),
        ]),
        one([
            bp_heading("Add your own videos", "How the videos system works", "Three steps and the page fills up."),
            iconlist([
                "WordPress → Videos → Add New: paste a YouTube / Vimeo link or upload an MP4",
                "Set the thumbnail (featured image), category, duration and description",
                "Publish — the grid, filters and single video pages update automatically",
            ]),
            button("Add a video", "/wp-admin/post-new.php?post_type=bp_video", bg=BRICK, color=WHITE),
        ], bg=SAND),
    ]


def locations():
    return [
        one([
            bp_heading("Locations", "Production sites and sales office",
                       "Every location card uses its real Google Maps link. Call or WhatsApp before visiting to "
                       "confirm loading times."),
            bp_location_cards(limit=4, show_products="yes"),
        ]),
        one([
            bp_heading("Directions", "Google Maps links",
                       "Tap a location to open Google Maps and start navigation."),
            rich(
                "<ul>"
                "<li><strong>Masha Allah Bricks Company – Ram Thaman:</strong> "
                "<a href=\"https://maps.app.goo.gl/6Pi5BNTsxPRkn1cn7?g_st=awb\" target=\"_blank\" rel=\"noopener\">open in Google Maps</a></li>"
                "<li><strong>Fine Bricks Company – Raja Jang:</strong> "
                "<a href=\"https://maps.app.goo.gl/SDaxqVM55qXt66wW8?g_st=awb\" target=\"_blank\" rel=\"noopener\">open in Google Maps</a></li>"
                "<li><strong>Masha Allah Bricks Company – Sattoki:</strong> "
                "<a href=\"https://www.google.com/maps?q=31.2328,74.3169424&amp;z=17&amp;hl=en\" target=\"_blank\" rel=\"noopener\">open in Google Maps</a></li>"
                "<li><strong>BrickPoint Office:</strong> "
                "<a href=\"https://maps.app.goo.gl/GACXw15YxyV4bK5t8?g_st=awb\" target=\"_blank\" rel=\"noopener\">open in Google Maps</a></li>"
                "</ul>"
                "<p><em>Edit the address, timings and phone number of each location in WordPress → Locations.</em></p>"
            ),
        ], bg=SAND),
        one([
            bp_heading("Visit or call", "Talk to us before you load", "Our sales office coordinates every delivery.", "center"),
            bp_contact_form("Contact our office", "Share your material list, quantity and delivery location.", "Send Inquiry", "Locations page"),
        ]),
    ]


def for_audience(title, intro, bullets, context, wa_message):
    return [
        one([
            bp_heading(title, intro['head'], intro['text']),
            iconlist(bullets),
            bp_whatsapp("WhatsApp our sales team", message=wa_message),
        ]),
        one([
            bp_heading("Send an inquiry", "We reply with availability and rates",
                       "Share your material list, quantity and delivery location.", "center"),
            bp_contact_form(title + " inquiry", "Material list, quantity and delivery location.", "Send Inquiry", context),
        ], bg=SAND),
        cta_section("Prefer WhatsApp?",
                    "Message us the material list and we will respond with rates and loading times.",
                    "Chat on WhatsApp", wa_message),
    ]


def contact():
    return [
        two(
            [
                bp_heading("Contact", "Send your material list",
                           "Fill the form or message us on WhatsApp. Our sales team confirms rates, availability "
                           "and the loading schedule."),
                rich(
                    "<p><strong>Sales office:</strong> Lahore, Punjab, Pakistan<br>"
                    "<strong>Phone / WhatsApp:</strong> editable in Appearance → Customize → BrickPoint</p>"
                    "<p><em>Update these details with your own verified contact information.</em></p>"
                ),
                bp_whatsapp("WhatsApp Us", message="Assalam-o-Alaikum BrickPoint, I would like a quotation.", style="whatsapp"),
            ],
            [
                bp_contact_form("Request a quotation", "Material, quantity and delivery location.", "Send Inquiry", "Contact page"),
            ],
            sizes=(50, 50),
        ),
        one([
            bp_heading("Our locations", "Production sites and office", "Google Maps links open the exact location."),
            bp_location_cards(limit=4),
        ], bg=SAND),
    ]


PAGES = {
    "home": home,
    "about-us": about,
    "products": products,
    "product-categories": product_categories,
    "ss7-bricks": ss7,
    "construction-materials": construction_materials,
    "projects": projects,
    "videos": videos,
    "locations": locations,
    "for-contractors": lambda: for_audience(
        "For Contractors",
        {"head": "Bulk material supply that keeps your site moving",
         "text": "BrickPoint supplies bricks and construction materials in bulk, with project-based quotations and "
                 "delivery coordination that fits your site schedule."},
        [
            "Bulk bricks and construction material supply",
            "Project-based quotations for one or many sites",
            "Delivery coordination with your site team",
            "Multiple product categories on a single inquiry",
            "Loading and dispatch updates on WhatsApp",
        ],
        "For Contractors page",
        "Assalam-o-Alaikum BrickPoint, I am a contractor and need a bulk material quotation.",
    ),
    "for-builders": lambda: for_audience(
        "For Builders",
        {"head": "Material sourcing support at every stage",
         "text": "From grey structure to finishing, BrickPoint supplies the materials a build needs with consistent "
                 "quality across consignments."},
        [
            "Construction material sourcing from one supplier",
            "Consistent quality across multiple consignments",
            "Bulk requirements handled on request",
            "Material scheduling support for your build plan",
            "One WhatsApp contact for the whole project",
        ],
        "For Builders page",
        "Assalam-o-Alaikum BrickPoint, I am a builder and would like material rates.",
    ),
    "contact": contact,
    "for-construction-companies": lambda: for_audience(
        "For Construction Companies",
        {"head": "Coordinate materials across multiple sites",
         "text": "One point of contact for material lists, delivery scheduling and documentation across your "
                 "running projects."},
        [
            "Large-scale supply coordination",
            "Material documentation on request",
            "Dedicated sales contact for corporate inquiries",
            "Structured inquiry workflow for procurement teams",
            "Delivery planning across multiple sites",
        ],
        "For Construction Companies page",
        "Assalam-o-Alaikum BrickPoint, we are a construction company and would like a supply quotation.",
    ),
}


def main():
    total = 0
    for slug, builder in sorted(PAGES.items()):
        data = builder()
        path = os.path.join(OUT, slug + '.json')
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1)
        widgets = json.dumps(data).count('"widgetType"')
        total += widgets
        print('%-28s sections=%-3d widgets=%d' % (slug, len(data), widgets))
    print('total widgets:', total)


if __name__ == '__main__':
    main()
