#!/usr/bin/env python3
"""
Build /home/user/brickpoint.zip from the theme source folder.

Deterministic: files are sorted and get a fixed timestamp so identical sources
produce identical archives. Skips editor/OS junk and anything that is not part
of the theme.
"""
import hashlib
import os
import sys
import zipfile

SRC = '/home/user/brickpoint'
OUT = '/home/user/brickpoint.zip'
ROOT = 'brickpoint'

SKIP_DIRS = {'.git', '.svn', 'node_modules', '__pycache__', 'raw', '.idea', '.vscode'}
SKIP_FILES = {'.DS_Store', 'Thumbs.db', '.gitignore', 'debug.log'}
SKIP_EXT = {'.pyc', '.log', '.zip', '.psd', '.xcf', '.tmp'}

FIXED_DATE = (2026, 9, 22, 12, 0, 0)


def collect():
    out = []
    for base, dirs, files in os.walk(SRC):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith('.'))
        for f in sorted(files):
            if f in SKIP_FILES or os.path.splitext(f)[1].lower() in SKIP_EXT or f.startswith('.'):
                continue
            full = os.path.join(base, f)
            rel = os.path.relpath(full, SRC)
            out.append((full, rel))
    return sorted(out, key=lambda t: t[1])


def main():
    files = collect()
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for full, rel in files:
            name = '%s/%s' % (ROOT, rel.replace(os.sep, '/'))
            info = zipfile.ZipInfo(name, date_time=FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            with open(full, 'rb') as fh:
                z.writestr(info, fh.read())
    size = os.path.getsize(OUT)
    sha = hashlib.sha256(open(OUT, 'rb').read()).hexdigest()
    print('files: %d' % len(files))
    print('bytes: %d' % size)
    print('sha256: %s' % sha)
    for full, rel in files:
        if os.path.getsize(full) > 200000:
            print('   big: %-46s %8.1f KB' % (rel, os.path.getsize(full) / 1024))
    return 0


if __name__ == '__main__':
    sys.exit(main())
